package com.travelous.service;

import com.travelous.dto.PromoResponse;

public interface PromoService {
    PromoResponse cekPromo(String kodePromo);
}
