package com.travelous.repository;

import com.travelous.model.KetersediaanHarian;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface KetersediaanRepository extends JpaRepository<KetersediaanHarian, String> {
    Optional<KetersediaanHarian> findByTanggalAndDestinasiId(java.util.Date tanggal, String destinasiId);
}
