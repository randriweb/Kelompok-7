package com.travelous.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Pemesanan {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String bookingId;

    @Temporal(TemporalType.DATE)
    private Date tanggalKunjungan;

    private String destinasiId;
    private String userId;
    private int jumlahTiket;
    private String status; // Pending, Confirmed, Cancelled

    // ===== Getter & Setter =====

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public Date getTanggalKunjungan() {
        return tanggalKunjungan;
    }

    public void setTanggalKunjungan(Date tanggalKunjungan) {
        this.tanggalKunjungan = tanggalKunjungan;
    }

    public String getDestinasiId() {
        return destinasiId;
    }

    public void setDestinasiId(String destinasiId) {
        this.destinasiId = destinasiId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getJumlahTiket() {
        return jumlahTiket;
    }

    public void setJumlahTiket(int jumlahTiket) {
        this.jumlahTiket = jumlahTiket;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
