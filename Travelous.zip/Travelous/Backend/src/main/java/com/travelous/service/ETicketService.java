package com.travelous.service;

import com.travelous.dto.ETicketResponse;

public interface ETicketService {
    ETicketResponse validasiETicket(String qrCode);
    ETicketResponse regenerateETicket(String bookingId);
}
