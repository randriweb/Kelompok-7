package com.travelous.repository;

import com.travelous.model.Pemesanan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PemesananRepository extends JpaRepository<Pemesanan, String> {
}
