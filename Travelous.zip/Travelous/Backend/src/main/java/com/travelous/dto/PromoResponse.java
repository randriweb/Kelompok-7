package com.travelous.dto;

public class PromoResponse {
    private boolean success;
    private String message;
    private int diskonPersen;

    public PromoResponse(boolean success, String message, int diskonPersen) {
        this.success = success;
        this.message = message;
        this.diskonPersen = diskonPersen;
    }

    // Getter & Setter
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getDiskonPersen() {
        return diskonPersen;
    }

    public void setDiskonPersen(int diskonPersen) {
        this.diskonPersen = diskonPersen;
    }
}