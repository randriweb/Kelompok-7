package com.travelous.dto;

public class PromoRequest {
    private String kodePromo;

    public PromoRequest() {}

    public String getKodePromo() {
        return kodePromo;
    }

    public void setKodePromo(String kodePromo) {
        this.kodePromo = kodePromo;
    }
}
