package com.travelous.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class MitraPayment {

    @Id
    private String paymentPartnerId;

    private String namaPartner;
    private String jenis; // QRIS, Bank Transfer, E-Wallet

    // ===== Getter & Setter =====

    public String getPaymentPartnerId() {
        return paymentPartnerId;
    }

    public void setPaymentPartnerId(String paymentPartnerId) {
        this.paymentPartnerId = paymentPartnerId;
    }

    public String getNamaPartner() {
        return namaPartner;
    }

    public void setNamaPartner(String namaPartner) {
        this.namaPartner = namaPartner;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }
}
