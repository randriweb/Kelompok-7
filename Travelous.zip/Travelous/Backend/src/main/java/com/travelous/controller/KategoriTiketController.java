package com.travelous.controller;

import com.travelous.model.KategoriTiket;
import com.travelous.service.KategoriTiketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/kategori-tiket")
public class KategoriTiketController {

    @Autowired
    private KategoriTiketService kategoriTiketService;

    @GetMapping("/destinasi/{destinasiId}")
    public ResponseEntity<List<KategoriTiket>> getByDestinasi(@PathVariable String destinasiId) {
        return ResponseEntity.ok(kategoriTiketService.getKategoriByDestinasi(destinasiId));
    }
}
