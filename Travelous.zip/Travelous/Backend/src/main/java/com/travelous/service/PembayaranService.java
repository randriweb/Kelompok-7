package com.travelous.service;

import com.travelous.dto.PembayaranRequest;
import com.travelous.dto.PembayaranResponse;

public interface PembayaranService {
    PembayaranResponse prosesPembayaran(PembayaranRequest request);
}
