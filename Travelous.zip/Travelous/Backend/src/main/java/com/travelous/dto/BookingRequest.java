package com.travelous.dto;

public class BookingRequest {
    private String destinasiId;
    private int jumlahTiket;
    private String tanggalKunjungan;
    private String userId;

    public BookingRequest() {}

    public String getDestinasiId() {
        return destinasiId;
    }

    public void setDestinasiId(String destinasiId) {
        this.destinasiId = destinasiId;
    }

    public int getJumlahTiket() {
        return jumlahTiket;
    }

    public void setJumlahTiket(int jumlahTiket) {
        this.jumlahTiket = jumlahTiket;
    }

    public String getTanggalKunjungan() {
        return tanggalKunjungan;
    }

    public void setTanggalKunjungan(String tanggalKunjungan) {
        this.tanggalKunjungan = tanggalKunjungan;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
