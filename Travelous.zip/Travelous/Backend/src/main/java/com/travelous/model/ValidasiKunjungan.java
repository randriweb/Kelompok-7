package com.travelous.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class ValidasiKunjungan {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String validasiId;

    @Temporal(TemporalType.DATE)
    private Date tanggalKunjungan;

    private String statusKunjungan;
    private String bookingId;

    // ===== Getter & Setter =====

    public String getValidasiId() {
        return validasiId;
    }

    public void setValidasiId(String validasiId) {
        this.validasiId = validasiId;
    }

    public Date getTanggalKunjungan() {
        return tanggalKunjungan;
    }

    public void setTanggalKunjungan(Date tanggalKunjungan) {
        this.tanggalKunjungan = tanggalKunjungan;
    }

    public String getStatusKunjungan() {
        return statusKunjungan;
    }

    public void setStatusKunjungan(String statusKunjungan) {
        this.statusKunjungan = statusKunjungan;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }
}
