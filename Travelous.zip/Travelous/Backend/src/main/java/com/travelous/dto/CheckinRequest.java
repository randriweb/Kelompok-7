package com.travelous.dto;

public class CheckinRequest {

    private String bookingId;

    // Getter
    public String getBookingId() {
        return bookingId;
    }

    // Setter
    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }
}