package com.travelous.repository;

import com.travelous.model.KategoriTiket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KategoriTiketRepository extends JpaRepository<KategoriTiket, String> {
    List<KategoriTiket> findByDestinasiId(String destinasiId);
}
