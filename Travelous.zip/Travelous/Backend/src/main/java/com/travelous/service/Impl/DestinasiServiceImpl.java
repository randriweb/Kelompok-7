package com.travelous.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.travelous.model.Destinasi;
import com.travelous.service.DestinasiService;

@Service
public class DestinasiServiceImpl implements DestinasiService {

    private final Map<String, Destinasi> destinasiMap = new HashMap<>();

    @Override
    public List<Destinasi> getAllDestinasi() {
        return new ArrayList<>(destinasiMap.values());
    }

    @Override
    public Destinasi getDestinasiById(String id) {
        return destinasiMap.get(id);
    }

    @Override
    public Destinasi tambahDestinasi(Destinasi destinasi) {
        destinasi.setId(UUID.randomUUID().toString());
        destinasiMap.put(destinasi.getId(), destinasi);
        return destinasi;
    }

    @Override
    public Destinasi editDestinasi(String id, Destinasi destinasi) {
        destinasi.setId(id);
        destinasiMap.put(id, destinasi);
        return destinasi;
    }

    @Override
    public void hapusDestinasi(String id) {
        destinasiMap.remove(id);
    }
}
