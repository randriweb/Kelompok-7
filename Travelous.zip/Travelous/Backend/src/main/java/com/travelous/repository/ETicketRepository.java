package com.travelous.repository;

import com.travelous.model.ETicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ETicketRepository extends JpaRepository<ETicket, String> {
}
