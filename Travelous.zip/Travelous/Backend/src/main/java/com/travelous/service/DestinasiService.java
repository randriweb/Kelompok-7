package com.travelous.service;

import com.travelous.model.Destinasi;

import java.util.List;

public interface DestinasiService {
    List<Destinasi> getAllDestinasi();
    Destinasi getDestinasiById(String id);
    Destinasi tambahDestinasi(Destinasi destinasi);
    Destinasi editDestinasi(String id, Destinasi destinasi);
    void hapusDestinasi(String id);
}
