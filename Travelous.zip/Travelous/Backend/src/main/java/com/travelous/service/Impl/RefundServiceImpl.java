package com.travelous.service.Impl;

import org.springframework.stereotype.Service;

import com.travelous.dto.RefundRequest;
import com.travelous.dto.RefundResponse;
import com.travelous.service.RefundService;

@Service
public class RefundServiceImpl implements RefundService {

    @Override
    public RefundResponse ajukanRefund(RefundRequest request) {
        // Simulasi logika pengajuan refund
        return new RefundResponse(true, "Permintaan refund dikirim", 50000);
    }

    @Override
    public RefundResponse prosesKeputusanRefund(String refundId, boolean disetujui) {
        String pesan = disetujui ? "Refund disetujui" : "Refund ditolak";
        double jumlah = disetujui ? 50000 : 0;
        return new RefundResponse(true, pesan, jumlah);
    }
}
