package com.travelous.controller;

import com.travelous.dto.RefundRequest;
import com.travelous.dto.RefundResponse;
import com.travelous.service.RefundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/refund")
public class RefundController {

    @Autowired
    private RefundService refundService;

    @PostMapping("/ajukan")
    public ResponseEntity<RefundResponse> ajukanRefund(@RequestBody RefundRequest request) {
        RefundResponse response = refundService.ajukanRefund(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/proses/{id}")
    public ResponseEntity<RefundResponse> prosesKeputusanRefund(@PathVariable String id, @RequestParam boolean disetujui) {
        RefundResponse response = refundService.prosesKeputusanRefund(id, disetujui);
        return ResponseEntity.ok(response);
    }
}
