package com.travelous.service.Impl;

import com.travelous.dto.PromoResponse;
import com.travelous.model.Promo;
import com.travelous.repository.PromoRepository;
import com.travelous.service.PromoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PromoServiceImpl implements PromoService {

    @Autowired
    private PromoRepository promoRepository;

    @Override
    public PromoResponse cekPromo(String kodePromo) {
        Optional<Promo> optionalPromo = promoRepository.findByKode(kodePromo);

        if (optionalPromo.isPresent()) {
            Promo promo = optionalPromo.get();
            return new PromoResponse(true, "Promo ditemukan.", promo.getDiskonPersen());
        } else {
            return new PromoResponse(false, "Kode promo tidak ditemukan.", 0);
        }
    }
}