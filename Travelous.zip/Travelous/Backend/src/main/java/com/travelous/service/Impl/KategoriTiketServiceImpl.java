package com.travelous.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.travelous.model.KategoriTiket;
import com.travelous.service.KategoriTiketService;

@Service
public class KategoriTiketServiceImpl implements KategoriTiketService {

    private final List<KategoriTiket> semuaKategori = new ArrayList<>();

    public KategoriTiketServiceImpl() {
        // Simulasi data dummy
        KategoriTiket k1 = new KategoriTiket();
        k1.setId("1");
        k1.setNamaKategori("Dewasa");
        k1.setDeskripsi("Tiket untuk usia 13 tahun ke atas");
        k1.setHargaDasar(50000);
        k1.setDestinasiId("A1");
        semuaKategori.add(k1);

        KategoriTiket k2 = new KategoriTiket();
        k2.setId("2");
        k2.setNamaKategori("Anak-anak");
        k2.setDeskripsi("Usia 5 - 12 tahun");
        k2.setHargaDasar(30000);
        k2.setDestinasiId("A1");
        semuaKategori.add(k2);
    }

    @Override
    public List<KategoriTiket> getKategoriByDestinasi(String destinasiId) {
        return semuaKategori.stream()
                .filter(k -> k.getDestinasiId().equals(destinasiId))
                .collect(Collectors.toList());
    }
}
