package com.travelous.service.Impl;

import com.travelous.dto.ETicketResponse;
import com.travelous.service.ETicketService;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class ETicketServiceImpl implements ETicketService {

    @Override
    public ETicketResponse validasiETicket(String qrCode) {
        // Validasi sederhana: QR harus tidak null dan diawali "QR-"
        boolean valid = qrCode != null && qrCode.startsWith("QR-");
        String message = valid ? "E-Ticket valid." : "QR Code tidak valid.";
        return new ETicketResponse(valid, message, null);
    }

    @Override
    public ETicketResponse regenerateETicket(String bookingId) {
        // Buat QR baru dengan format unik
        String newQr = "QR-" + UUID.randomUUID().toString();
        return new ETicketResponse(true, "QR baru berhasil dibuat.", newQr);
    }
}
