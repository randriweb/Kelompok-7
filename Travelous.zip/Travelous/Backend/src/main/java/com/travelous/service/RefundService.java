package com.travelous.service;

import com.travelous.dto.RefundRequest;
import com.travelous.dto.RefundResponse;

public interface RefundService {
    RefundResponse ajukanRefund(RefundRequest request);
    RefundResponse prosesKeputusanRefund(String refundId, boolean disetujui);
}
