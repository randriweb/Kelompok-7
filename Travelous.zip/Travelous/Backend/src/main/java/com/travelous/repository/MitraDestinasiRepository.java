package com.travelous.repository;

import com.travelous.model.MitraDestinasi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MitraDestinasiRepository extends JpaRepository<MitraDestinasi, String> {
}
