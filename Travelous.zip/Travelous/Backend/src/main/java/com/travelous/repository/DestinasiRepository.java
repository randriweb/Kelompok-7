package com.travelous.repository;

import com.travelous.model.Destinasi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DestinasiRepository extends JpaRepository<Destinasi, String> {
}
