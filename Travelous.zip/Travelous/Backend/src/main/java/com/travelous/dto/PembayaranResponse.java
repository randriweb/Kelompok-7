package com.travelous.dto;

public class PembayaranResponse {
    private boolean success;
    private String message;
    private double total;

    public PembayaranResponse() {}

    public PembayaranResponse(boolean success, String message, double total) {
        this.success = success;
        this.message = message;
        this.total = total;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
