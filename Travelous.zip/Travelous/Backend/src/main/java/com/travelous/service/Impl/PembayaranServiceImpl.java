package com.travelous.service.Impl;

import org.springframework.stereotype.Service;

import com.travelous.dto.PembayaranRequest;
import com.travelous.dto.PembayaranResponse;
import com.travelous.service.PembayaranService;

@Service
public class PembayaranServiceImpl implements PembayaranService {

    @Override
    public PembayaranResponse prosesPembayaran(PembayaranRequest request) {
        // Simulasi proses perhitungan & penyimpanan pembayaran
        double total = 150000; // Dummy, nanti hitung dari DB
        double diskon = request.getKodePromo() != null ? 20000 : 0;
        double finalTotal = total - diskon;

        return new PembayaranResponse(true, "Pembayaran berhasil", finalTotal);
    }
}
