package com.travelous.repository;

import com.travelous.model.Tiket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TiketRepository extends JpaRepository<Tiket, String> {
}
