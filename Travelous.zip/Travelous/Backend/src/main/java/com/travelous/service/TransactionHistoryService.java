package com.travelous.service;

import com.travelous.model.TransactionHistory;

import java.util.List;

public interface TransactionHistoryService {
    List<TransactionHistory> getHistoryByUser(String userId);
}
