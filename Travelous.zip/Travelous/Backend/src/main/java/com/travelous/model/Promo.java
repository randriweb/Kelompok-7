package com.travelous.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Promo {

    @Id
    private String kode;

    private int diskonPersen;

    // Getter & Setter
    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public int getDiskonPersen() {
        return diskonPersen;
    }

    public void setDiskonPersen(int diskonPersen) {
        this.diskonPersen = diskonPersen;
    }
}