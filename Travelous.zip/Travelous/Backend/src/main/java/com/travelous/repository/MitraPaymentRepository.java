package com.travelous.repository;

import com.travelous.model.MitraPayment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MitraPaymentRepository extends JpaRepository<MitraPayment, String> {
}
