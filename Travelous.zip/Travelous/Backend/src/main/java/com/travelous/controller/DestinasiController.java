package com.travelous.controller;

import com.travelous.model.Destinasi;
import com.travelous.service.DestinasiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/destinasi")
public class DestinasiController {

    @Autowired
    private DestinasiService destinasiService;

    @GetMapping
    public ResponseEntity<List<Destinasi>> getAllDestinasi() {
        return ResponseEntity.ok(destinasiService.getAllDestinasi());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Destinasi> getById(@PathVariable String id) {
        return ResponseEntity.ok(destinasiService.getDestinasiById(id));
    }

    @PostMapping("/tambah")
    public ResponseEntity<Destinasi> tambah(@RequestBody Destinasi destinasi) {
        return ResponseEntity.ok(destinasiService.tambahDestinasi(destinasi));
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<Destinasi> edit(@PathVariable String id, @RequestBody Destinasi destinasi) {
        return ResponseEntity.ok(destinasiService.editDestinasi(id, destinasi));
    }

    @DeleteMapping("/hapus/{id}")
    public ResponseEntity<String> hapus(@PathVariable String id) {
        destinasiService.hapusDestinasi(id);
        return ResponseEntity.ok("Destinasi dihapus.");
    }
}
