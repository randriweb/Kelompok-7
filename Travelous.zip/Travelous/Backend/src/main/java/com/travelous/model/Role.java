package com.travelous.model;

public enum Role {
    ROLE_USER,
    ROLE_MITRA,
    ROLE_ADMIN
}
