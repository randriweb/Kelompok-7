package com.travelous.repository;

import com.travelous.model.ValidasiKunjungan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ValidasiKunjunganRepository extends JpaRepository<ValidasiKunjungan, String> {
}
