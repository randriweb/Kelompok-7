package com.travelous.service;

import com.travelous.dto.BookingRequest;
import com.travelous.dto.BookingResponse;

public interface BookingService {
    BookingResponse buatPemesanan(BookingRequest request);
}
