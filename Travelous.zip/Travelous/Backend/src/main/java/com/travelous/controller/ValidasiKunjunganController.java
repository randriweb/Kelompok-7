package com.travelous.controller;

import com.travelous.dto.CheckinRequest;
import com.travelous.dto.CheckinResponse;
import com.travelous.service.ValidasiKunjunganService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/kunjungan")
public class ValidasiKunjunganController {

    @Autowired
    private ValidasiKunjunganService kunjunganService;

    @PostMapping("/checkin")
    public ResponseEntity<CheckinResponse> checkin(@RequestBody CheckinRequest request) {
        CheckinResponse response = kunjunganService.checkin(request);
        return ResponseEntity.ok(response);
    }
}
