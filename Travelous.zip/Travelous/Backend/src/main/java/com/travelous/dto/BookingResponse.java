package com.travelous.dto;

public class BookingResponse {
    private boolean sukses;
    private String message;
    private String bookingId;

    public BookingResponse() {
    }

    public BookingResponse(boolean sukses, String message, String bookingId) {
        this.sukses = sukses;
        this.message = message;
        this.bookingId = bookingId;
    }

    public boolean isSukses() {
        return sukses;
    }

    public void setSukses(boolean sukses) {
        this.sukses = sukses;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }
}
