package com.travelous.service.Impl;

import com.travelous.dto.CheckinRequest;
import com.travelous.dto.CheckinResponse;
import com.travelous.model.ValidasiKunjungan;
import com.travelous.repository.ValidasiKunjunganRepository;
import com.travelous.service.ValidasiKunjunganService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class ValidasiKunjunganServiceImpl implements ValidasiKunjunganService {

    @Autowired
    private ValidasiKunjunganRepository validasiKunjunganRepository;

    @Override
    public CheckinResponse checkin(CheckinRequest request) {
        ValidasiKunjungan validasi = new ValidasiKunjungan();
        validasi.setValidasiId(UUID.randomUUID().toString());
        validasi.setBookingId(request.getBookingId());
        validasi.setTanggalKunjungan(new Date());
        validasi.setStatusKunjungan("CHECKED_IN");

        validasiKunjunganRepository.save(validasi);

        return new CheckinResponse(true, "Check-in berhasil", validasi.getValidasiId());
    }
}