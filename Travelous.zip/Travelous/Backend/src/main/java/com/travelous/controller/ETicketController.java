package com.travelous.controller;

import com.travelous.dto.ETicketRequest;
import com.travelous.dto.ETicketResponse;
import com.travelous.service.ETicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/eticket")
public class ETicketController {

    @Autowired
    private ETicketService eticketService;

    @PostMapping("/validasi")
    public ResponseEntity<ETicketResponse> validasi(@RequestBody ETicketRequest request) {
        ETicketResponse response = eticketService.validasiETicket(request.getQrCode());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/regenerate")
    public ResponseEntity<ETicketResponse> regenerate(@RequestBody ETicketRequest request) {
        ETicketResponse response = eticketService.regenerateETicket(request.getBookingId());
        return ResponseEntity.ok(response);
    }
}
