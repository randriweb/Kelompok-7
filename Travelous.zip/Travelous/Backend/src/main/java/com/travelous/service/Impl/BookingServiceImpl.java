package com.travelous.service.Impl;

import com.travelous.dto.BookingRequest;
import com.travelous.dto.BookingResponse;
import com.travelous.model.Pemesanan;
import com.travelous.repository.PemesananRepository;
import com.travelous.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@Service
public class BookingServiceImpl implements BookingService {

    @Autowired
    private PemesananRepository pemesananRepository;

    @Override
    public BookingResponse buatPemesanan(BookingRequest request) {
        Pemesanan pemesanan = new Pemesanan();
        pemesanan.setBookingId(UUID.randomUUID().toString());
        pemesanan.setDestinasiId(request.getDestinasiId());
        pemesanan.setJumlahTiket(request.getJumlahTiket());

        try {
            // Format: sesuaikan dengan format tanggal dari frontend (misal "yyyy-MM-dd")
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date tanggalKunjungan = sdf.parse(request.getTanggalKunjungan());
            pemesanan.setTanggalKunjungan(tanggalKunjungan);
        } catch (ParseException e) {
            throw new RuntimeException("Format tanggal tidak valid. Gunakan yyyy-MM-dd");
        }

        pemesanan.setUserId(request.getUserId());
        pemesanan.setStatus("PENDING");

        pemesananRepository.save(pemesanan);

        return new BookingResponse(true, "Pemesanan berhasil dibuat.", pemesanan.getBookingId());
    }
}
