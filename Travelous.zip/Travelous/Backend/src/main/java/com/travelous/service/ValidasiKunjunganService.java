package com.travelous.service;

import com.travelous.dto.CheckinRequest;
import com.travelous.dto.CheckinResponse;

public interface ValidasiKunjunganService {
    CheckinResponse checkin(CheckinRequest request);
}
