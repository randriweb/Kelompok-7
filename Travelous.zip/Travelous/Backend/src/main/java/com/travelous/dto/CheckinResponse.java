package com.travelous.dto;

public class CheckinResponse {
    private boolean success;
    private String message;
    private String validasiId;

    // Constructor
    public CheckinResponse(boolean success, String message, String validasiId) {
        this.success = success;
        this.message = message;
        this.validasiId = validasiId;
    }

    // Getter & Setter
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getValidasiId() {
        return validasiId;
    }

    public void setValidasiId(String validasiId) {
        this.validasiId = validasiId;
    }
}