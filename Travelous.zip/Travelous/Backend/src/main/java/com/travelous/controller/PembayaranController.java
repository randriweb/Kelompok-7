package com.travelous.controller;

import com.travelous.dto.PembayaranRequest;
import com.travelous.dto.PembayaranResponse;
import com.travelous.service.PembayaranService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pembayaran")
public class PembayaranController {

    @Autowired
    private PembayaranService pembayaranService;

    @PostMapping("/proses")
    public ResponseEntity<PembayaranResponse> prosesPembayaran(@Valid @RequestBody PembayaranRequest request) {
        return ResponseEntity.ok(pembayaranService.prosesPembayaran(request));
    }
}
