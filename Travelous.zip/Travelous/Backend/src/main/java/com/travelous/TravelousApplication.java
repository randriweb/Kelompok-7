package com.travelous;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelousApplication {

    public static void main(String[] args) {
        SpringApplication.run(TravelousApplication.class, args);
    }
}
