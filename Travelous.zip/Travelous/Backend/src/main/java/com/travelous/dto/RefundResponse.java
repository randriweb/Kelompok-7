package com.travelous.dto;

public class RefundResponse {
    private boolean success;
    private String message;
    private double amount;

    public RefundResponse() {}

    public RefundResponse(boolean success, String message, double amount) {
        this.success = success;
        this.message = message;
        this.amount = amount;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
