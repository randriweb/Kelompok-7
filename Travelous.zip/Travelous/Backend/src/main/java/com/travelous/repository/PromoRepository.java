package com.travelous.repository;

import com.travelous.model.Promo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PromoRepository extends JpaRepository<Promo, String> {
    Optional<Promo> findByKode(String kode);
}