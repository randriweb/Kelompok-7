package com.travelous.service.Impl;

import com.travelous.model.TransactionHistory;
import com.travelous.repository.TransactionHistoryRepository;
import com.travelous.service.TransactionHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionHistoryServiceImpl implements TransactionHistoryService {

    @Autowired
    private TransactionHistoryRepository transactionHistoryRepository;

    @Override
    public List<TransactionHistory> getHistoryByUser(String userId) {
        return transactionHistoryRepository.findAllByUserId(userId);
    }
}
