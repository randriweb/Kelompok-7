package com.travelous.service;

import com.travelous.model.KategoriTiket;

import java.util.List;

public interface KategoriTiketService {
    List<KategoriTiket> getKategoriByDestinasi(String destinasiId);
}
