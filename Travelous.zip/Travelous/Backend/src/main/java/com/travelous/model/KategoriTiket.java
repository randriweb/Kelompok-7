package com.travelous.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class KategoriTiket {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String namaKategori;
    private String deskripsi;
    private double hargaDasar;
    private String destinasiId;

    // ===== Getter & Setter =====

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNamaKategori() {
        return namaKategori;
    }

    public void setNamaKategori(String namaKategori) {
        this.namaKategori = namaKategori;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public double getHargaDasar() {
        return hargaDasar;
    }

    public void setHargaDasar(double hargaDasar) {
        this.hargaDasar = hargaDasar;
    }

    public String getDestinasiId() {
        return destinasiId;
    }

    public void setDestinasiId(String destinasiId) {
        this.destinasiId = destinasiId;
    }
}
