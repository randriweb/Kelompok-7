package com.travelous.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.travelous.dto.RegisterRequest;
import com.travelous.model.User;

public interface AuthService extends UserDetailsService {
    User authenticate(String email, String password);
    void registerUser(RegisterRequest registerRequest);
    void sendResetLink(String email);
}
