package com.travelous.repository;

import com.travelous.model.Pembayaran;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PembayaranRepository extends JpaRepository<Pembayaran, String> {
}
