package com.travelous.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class ETicket {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String eTicketId;

    private String qrCode;
    private String status;

    @Temporal(TemporalType.TIMESTAMP)
    private Date expiryDate;

    // ===== Getter & Setter =====

    public String geteTicketId() {
        return eTicketId;
    }

    public void seteTicketId(String eTicketId) {
        this.eTicketId = eTicketId;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
}
