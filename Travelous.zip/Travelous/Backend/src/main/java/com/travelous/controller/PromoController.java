package com.travelous.controller;

import com.travelous.dto.PromoRequest;
import com.travelous.dto.PromoResponse;
import com.travelous.service.PromoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/promo")
public class PromoController {

    @Autowired
    private PromoService promoService;

    @PostMapping("/cek")
    public ResponseEntity<PromoResponse> cekPromo(@RequestBody PromoRequest request) {
        PromoResponse response = promoService.cekPromo(request.getKodePromo());
        return ResponseEntity.ok(response);
    }
}
