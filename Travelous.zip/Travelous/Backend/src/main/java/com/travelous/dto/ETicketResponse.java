package com.travelous.dto;

public class ETicketResponse {
    private boolean success;
    private String message;
    private String qrCode;

    public ETicketResponse(boolean success, String message, String qrCode) {
        this.success = success;
        this.message = message;
        this.qrCode = qrCode;
    }

    // Getter & Setter
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }
}