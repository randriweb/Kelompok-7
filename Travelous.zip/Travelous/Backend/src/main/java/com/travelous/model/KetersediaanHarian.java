package com.travelous.model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class KetersediaanHarian {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Temporal(TemporalType.DATE)
    private Date tanggal;

    private int kuota;
    private int kuotaTerpakai;
    private String destinasiId;

    // ===== Getter & Setter =====

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }

    public int getKuota() {
        return kuota;
    }

    public void setKuota(int kuota) {
        this.kuota = kuota;
    }

    public int getKuotaTerpakai() {
        return kuotaTerpakai;
    }

    public void setKuotaTerpakai(int kuotaTerpakai) {
        this.kuotaTerpakai = kuotaTerpakai;
    }

    public String getDestinasiId() {
        return destinasiId;
    }

    public void setDestinasiId(String destinasiId) {
        this.destinasiId = destinasiId;
    }
}
