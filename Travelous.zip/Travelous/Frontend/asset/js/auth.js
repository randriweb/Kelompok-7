document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");

    if (loginForm) {
        loginForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const email = loginForm.email.value;
            const password = loginForm.password.value;

            const result = await fetchPOST("/auth/login", { email, password });
            if (result.token) {
                localStorage.setItem("token", result.token);
                localStorage.setItem("role", result.role);
                alert("Login berhasil!");
                window.location.href = "index.html";
            } else {
                alert("Login gagal!");
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const data = {
                username: registerForm.username.value,
                email: registerForm.email.value,
                password: registerForm.password.value,
                phoneNumber: registerForm.phoneNumber.value,
                role: registerForm.role.value
            };
            const result = await fetchPOST("/auth/register", data);
            alert("Registrasi berhasil. Silakan login.");
            window.location.href = "login.html";
        });
    }
});
