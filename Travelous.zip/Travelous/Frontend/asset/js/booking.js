document.addEventListener("DOMContentLoaded", () => {
    const bookingForm = document.getElementById("bookingForm");
    const promoInput = document.getElementById("promoKode");
    const totalEl = document.getElementById("totalHarga");

    let diskon = 0;

    if (promoInput) {
        promoInput.addEventListener("blur", async () => {
            const result = await fetchPOST("/promo/cek", { kodePromo: promoInput.value }, true);
            if (result.valid) {
                diskon = result.diskon;
                alert("Promo valid: -Rp" + diskon);
            } else {
                alert("Kode promo tidak valid");
                diskon = 0;
            }
        });
    }

    if (bookingForm) {
        bookingForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const data = {
                destinasiId: bookingForm.destinasiId.value,
                tanggalKunjungan: bookingForm.tanggal.value,
                jumlahTiket: parseInt(bookingForm.jumlah.value),
                userId: bookingForm.userId.value
            };
            const result = await fetchPOST("/pemesanan/buat", data, true);
            if (result.sukses) {
                alert("Booking berhasil, ID: " + result.bookingId);
                window.location.href = "eticket.html?bookingId=" + result.bookingId;
            } else {
                alert("Gagal booking: " + result.message);
            }
        });
    }
});
