document.addEventListener("DOMContentLoaded", async () => {
    const userId = localStorage.getItem("userId");
    const container = document.getElementById("riwayatTransaksi");

    if (userId && container) {
        const data = await fetchGET(`/transaksi/user/${userId}`, true);
        data.forEach(tx => {
            const el = document.createElement("div");
            el.innerHTML = `
                <p><strong>${tx.bookingId}</strong> - Rp${tx.amount} - ${new Date(tx.date).toLocaleDateString()}</p>
            `;
            container.appendChild(el);
        });
    }
});
