async function cekPromo(kodePromo) {
    const res = await fetchPOST("/promo/cek", { kodePromo }, true);
    return res;
}
