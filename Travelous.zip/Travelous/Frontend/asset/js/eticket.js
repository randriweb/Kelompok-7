document.addEventListener("DOMContentLoaded", () => {
    const qrBox = document.getElementById("qrCodeDisplay");
    const bookingId = new URLSearchParams(window.location.search).get("bookingId");

    if (bookingId && qrBox) {
        // Simulasi QR Code
        const fakeQr = "QR-" + bookingId;
        qrBox.innerText = fakeQr;
    }

    const validasiBtn = document.getElementById("validasiBtn");
    if (validasiBtn) {
        validasiBtn.addEventListener("click", async () => {
            const qrCode = qrBox.innerText;
            const result = await fetchPOST("/eticket/validasi", { qrCode }, true);
            alert(result.message);
        });
    }

    const regenerateBtn = document.getElementById("regenerateBtn");
    if (regenerateBtn) {
        regenerateBtn.addEventListener("click", async () => {
            const result = await fetchPOST("/eticket/regenerate", { bookingId }, true);
            alert(result.message);
            qrBox.innerText = result.newQrCode;
        });
    }
});
